//
//  UIViewExtantion.swift
//  Demo Project 1
//
//  Created by Maddy on 30.11.20.
//

import UIKit

extension UIButton {

    func addUIButton (){
        heightAnchor.constraint(equalToConstant: 100).isActive = true
    }

}
