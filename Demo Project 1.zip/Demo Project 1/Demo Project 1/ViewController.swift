//
//  ViewController.swift
//  Demo Project 1
//
//  Created by Maddy on 30.11.20.
//

import UIKit

class ViewController: UIViewController {
    
    let button1: UIButton = {
        let button1 = UIButton(type: .system)
        button1.setTitle("Push me", for: .normal)
        button1.translatesAutoresizingMaskIntoConstraints = false
        button1.backgroundColor = .red
        return button1
    }()
    
    let button2: UIButton = {
        let button2 = UIButton(type: .system)
        button2.setTitle("Press me", for: .normal)
        button2.translatesAutoresizingMaskIntoConstraints = false
        button2.backgroundColor = .blue
        return button2
    }()
    

    override func viewDidLoad() {
        super.viewDidLoad()
       
        
        let vc = UIViewController()
            vc.view.backgroundColor = UIColor.purple
            vc.title = "Red"
            navigationController?.pushViewController(vc, animated: true)
        
        view.addSubview(button1)
        view.addSubview(button2)
        
        setUpButton1()
        setUpButton2()
        
        }
    
       
    func setUpButton1(){
        button1.leftAnchor.constraint(equalTo: view.leftAnchor).isActive = true
        button1.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 1/3).isActive = true
        button1.centerYAnchor.constraint(equalTo: view.centerYAnchor).isActive = true
    }
    
    func setUpButton2(){
        button2.rightAnchor.constraint(equalTo: view.rightAnchor).isActive = true
        button2.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 1/3).isActive = true
        button2.centerYAnchor.constraint(equalTo: view.centerYAnchor).isActive = true
    }
    
    @objc func button1Tapped(_ sender: SecondViewController){
        let vc = SecondViewController()
        navigationController?.pushViewController(vc, animated: true)
    }

        }
        
       
    




