//
//  SecondViewController.swift
//  Demo Project 1
//
//  Created by Maddy on 30.11.20.
//

import UIKit

class SecondViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        let vc1 = UIViewController()
            vc1.view.backgroundColor = UIColor.yellow
            vc1.title = "hello"
            navigationController?.pushViewController(vc1, animated: true)
    }


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
