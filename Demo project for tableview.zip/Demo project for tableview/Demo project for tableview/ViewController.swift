//
//  ViewController.swift
//  Demo project for tableview
//
//  Created by Maddy on 3.12.20.
//

import UIKit

class ViewController: UIViewController {
    
    var categories = LanguageCategory.allLanguages
    
    
}

    
extension ViewController:UITableViewDataSource, UITableViewDelegate {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return categories.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return categories[section].countryOfUse.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .subtitle, reuseIdentifier: nil)
        
        let language = categories[indexPath.section].countryOfUse[indexPath.row]
        
        cell.textLabel?.text = language.title
        cell.detailTextLabel?.text = language.country
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return categories[section].title
    }
    
    
}


