//
//  SecondViewController.swift
//  demo project
//
//  Created by Maddy on 26.11.20.
//

import UIKit

class SecondViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Second"

        // Do any additional setup after loading the view.
        
        
        let mvc1 = UIViewController()
        mvc1.view.backgroundColor = UIColor.blue
        mvc1.title = "red"
        navigationController?.pushViewController(mvc1, animated: true)
    }


    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @IBAction func showRateTab(_ sender: Any){
        tabBarController?.selectedIndex = 1
    }
    
    @IBAction func buttonCloseClicked(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    

}
